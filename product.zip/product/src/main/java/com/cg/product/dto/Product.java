package com.cg.product.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	
	
	@Column(name="name",length=20)
	private String name;
	@Id
	@Column(name="id",length=10)
	private String id;
	@Column(name="price",length=5)
	private String price;
	public Product() {
		
		
	}
	public Product(String name, String id, String price) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [name=" + name + ", id=" + id + ", price=" + price + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

}
