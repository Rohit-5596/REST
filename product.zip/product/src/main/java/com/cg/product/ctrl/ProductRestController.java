package com.cg.product.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exceptions.UserNotFoundException;
import com.cg.product.service.ProductService;
@RestController
public class ProductRestController {

	@Autowired
	ProductService logSer;

	@RequestMapping(value = "/showAllUsers", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Product> showAllUsers() {
		System.out.println("--------UserRestController");
		return logSer.getAllUsers();
	}
	@PostMapping(value="/addUser",consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",produces=MediaType.APPLICATION_JSON_VALUE)
     public Product createUser(@RequestBody Product log) 
     {
		logSer.addUser(log);
		Product lgg=logSer.getUserbyUserName(log.getName());
		return lgg;
    	 
     }
	@DeleteMapping(value="/deleteUser/{uid}",headers="Accept=application/json")
    public String deleteUser(@PathVariable("uid") String unm) 
    {
        logSer.deleteUserByUserName(unm);
        return ("Data deleted.....");
   	  
    }
	
	@PutMapping(value="/user/update/",consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public void updateUser(@RequestBody Product lg) {
		System.out.println("okay okay here");
		logSer.updateUserInfo(lg.getPrice(),lg.getId(),lg.getName());
		System.out.println("Data Updated in the table");
	}
	
	
	
	
	
	@GetMapping(value="searchUser/{uid}")
	public Product searchUserById(@PathVariable("uid") String unm) throws UserNotFoundException{
		
		Product lgg=logSer.getUserbyUserName(unm);
		if(lgg==null) {
			throw new UserNotFoundException("No user with this id");
		}
		else {
			return lgg;
		}
		
	}
}
