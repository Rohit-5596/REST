package com.cg.product.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.cg.product.dto.Product;


@Service
public interface ProductService {
	 public ArrayList<Product> getAllUsers();
	   public Product addUser(Product log);
	   public Product getUserbyUserName(String unm);
	   public void deleteUserByUserName(String unm);
	 
	public void updateUserInfo(String pr, String id, String nm);

}
