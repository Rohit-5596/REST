package com.cg.product.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;

@Repository("proJparepository")
@Transactional

public interface ProductRepository extends JpaRepository<Product, String> {
	@Query("Select userList FROM Product userList")
	public ArrayList<Product> getAllUsers();

	@Query("SELECT pro FROM Product pro where pro.name=:nm")
	public Product getUserbyUserName(@Param("nm") String nm);

	@Transactional
	@Modifying
	@Query("DELETE FROM Product pro WHERE pro.name=:nm")
	public void deleteUserByUserName(@Param("nm") String nm);

	@Modifying
	@Query("Update Product pro SET pro.price=:pr,pro.id=:id WHERE pro.name=:nm")

	public void updateUserInfo(@Param("pr") String pr, @Param("id") String id, @Param("nm") String nm);

}
